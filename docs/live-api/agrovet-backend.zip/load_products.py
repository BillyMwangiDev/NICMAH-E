import os
import sys
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
BACKEND_DIR = BASE / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from dotenv import load_dotenv
load_dotenv(BACKEND_DIR / ".env")

os.environ["DJANGO_SETTINGS_MODULE"] = "agrovet.settings.production"

import django
django.setup()

from django.core.management import call_command
call_command("loaddata", str(BACKEND_DIR / "inventory" / "fixtures" / "initial_products.json"))
print("Products loaded!")

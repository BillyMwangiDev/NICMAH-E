import sys
import os
import logging
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
BACKEND_DIR = BASE_DIR / "backend"
if not BACKEND_DIR.exists():
    BACKEND_DIR = BASE_DIR

sys.path.insert(0, str(BACKEND_DIR))

# Write all startup activity to startup.log — readable via File Manager
logging.basicConfig(
    filename=str(BASE_DIR / "startup.log"),
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s",
)
log = logging.getLogger("passenger_wsgi")

# Load .env
try:
    from dotenv import load_dotenv
    env_path = BACKEND_DIR / ".env"
    loaded = load_dotenv(env_path)
    log.info(".env loaded from %s (found=%s)", env_path, loaded)
except Exception as exc:
    log.error("Failed to load .env: %s", exc)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "agrovet.settings.production")


def _ensure_django():
    import django
    from django.apps import apps
    if not apps.ready:
        django.setup()


# ── First-time setup: migrate + collectstatic ─────────────────────────────────
_setup_flag = BASE_DIR / ".setup_done"
if not _setup_flag.exists():
    try:
        log.info("Running first-time setup (migrate + collectstatic)...")
        _ensure_django()
        from django.core.management import call_command
        call_command("migrate", "--run-syncdb", verbosity=0)
        call_command("collectstatic", "--noinput", verbosity=0)
        _setup_flag.touch()
        log.info("First-time setup complete.")
    except Exception as exc:
        log.error("First-time setup failed: %s", exc, exc_info=True)

# ── Load initial products ─────────────────────────────────────────────────────
_products_flag = BASE_DIR / ".products_loaded"
if not _products_flag.exists():
    try:
        log.info("Loading initial products...")
        _ensure_django()
        from django.core.management import call_command
        fixture = BACKEND_DIR / "inventory" / "fixtures" / "initial_products.json"
        call_command("loaddata", str(fixture), verbosity=0)
        _products_flag.touch()
        log.info("Products loaded.")
    except Exception as exc:
        log.error("Product load failed: %s", exc, exc_info=True)

# ── Create superuser ──────────────────────────────────────────────────────────
_superuser_flag = BASE_DIR / ".superuser_done"
if not _superuser_flag.exists():
    try:
        su_username = os.environ.get("DJANGO_SUPERUSER_USERNAME")
        su_email = os.environ.get("DJANGO_SUPERUSER_EMAIL")
        su_password = os.environ.get("DJANGO_SUPERUSER_PASSWORD")
        if su_username and su_password:
            log.info("Creating superuser...")
            _ensure_django()
            from django.contrib.auth import get_user_model
            User = get_user_model()
            if not User.objects.filter(username=su_username).exists():
                User.objects.create_superuser(
                    username=su_username,
                    email=su_email or "",
                    password=su_password,
                )
                log.info("Superuser '%s' created.", su_username)
            else:
                log.info("Superuser '%s' already exists.", su_username)
            _superuser_flag.touch()
        else:
            log.warning("Skipping superuser: DJANGO_SUPERUSER_USERNAME / DJANGO_SUPERUSER_PASSWORD not set.")
    except Exception as exc:
        log.error("Superuser creation failed: %s", exc, exc_info=True)

# ── WSGI application ──────────────────────────────────────────────────────────
try:
    _ensure_django()
    from django.core.wsgi import get_wsgi_application
    application = get_wsgi_application()
    log.info("Django WSGI application ready.")
except Exception as exc:
    log.error("CRITICAL: Django WSGI failed to load: %s", exc, exc_info=True)

    # Always define application so Passenger doesn't crash with "No such application"
    _err = (
        b"Django failed to start. "
        b"Check startup.log in /home3/nicmahco/api.nicmah.com/ for details."
    )

    def application(_environ, start_response):
        start_response("500 Internal Server Error", [
            ("Content-Type", "text/plain"),
            ("Content-Length", str(len(_err))),
        ])
        return [_err]

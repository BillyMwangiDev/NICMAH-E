"""
One-off: apply the inventory migrations (adds the Vaccines category) on the live
server. Run from Setup Python App > Execute python script, then restart the app.
Mirrors passenger_wsgi.py's environment setup so it hits the production database.
Writes its output to migrate_vaccines.log next to this file.
"""
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
BACKEND_DIR = BASE_DIR / "backend"
sys.path.insert(0, str(BACKEND_DIR))

log_path = BASE_DIR / "migrate_vaccines.log"
log = open(log_path, "a", encoding="utf-8")
sys.stdout = log
sys.stderr = log

try:
    from dotenv import load_dotenv
    load_dotenv(BACKEND_DIR / ".env")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "agrovet.settings.production")

    import django
    django.setup()
    from django.conf import settings
    from django.core.management import call_command

    print("settings:", settings.SETTINGS_MODULE, "db engine:", settings.DATABASES["default"]["ENGINE"])
    call_command("showmigrations", "inventory", verbosity=1)
    call_command("migrate", "inventory", verbosity=1)

    from inventory.models import Category
    vaccines = Category.objects.filter(slug="vaccines").first()
    print("vaccines:", vaccines, "| subcategories:",
          list(Category.objects.filter(parent=vaccines).values_list("slug", flat=True)) if vaccines else None)
    print("DONE OK")
except Exception as exc:  # noqa: BLE001
    import traceback
    traceback.print_exc()
    print("DONE WITH ERROR:", exc)
finally:
    log.flush()
    log.close()

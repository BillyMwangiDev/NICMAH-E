import os
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
BACKEND_DIR = BASE / "backend"
sys.path.insert(0, str(BACKEND_DIR))

from dotenv import load_dotenv
load_dotenv(BACKEND_DIR / ".env")

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "agrovet.settings.production")

import django
django.setup()

from django.contrib.auth import get_user_model
User = get_user_model()

username = os.environ["DJANGO_SUPERUSER_USERNAME"]
email = os.environ.get("DJANGO_SUPERUSER_EMAIL", "")
password = os.environ["DJANGO_SUPERUSER_PASSWORD"]

if not User.objects.filter(username=username).exists():
    User.objects.create_superuser(username=username, email=email, password=password)
    print(f"Superuser '{username}' created.")
else:
    print(f"User '{username}' already exists.")
